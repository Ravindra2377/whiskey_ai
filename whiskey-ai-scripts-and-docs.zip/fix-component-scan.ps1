# Script to fix the component scan in WhiskeyApplication.java

# Define the file path
$filePath = "D:\OneDrive\Desktop\WHISKEY_Standalone\whiskey-ai\src\main\java\com\whiskey\ai\WhiskeyApplication.java"

# Read the content of the file
$content = Get-Content $filePath

# Replace the old component scan with the new one
$updatedContent = $content -replace 'com\.boozer\.whiskey', 'com.whiskey.ai'

# Write the updated content back to the file
Set-Content $filePath $updatedContent

Write-Host "Component scan fixed successfully!"