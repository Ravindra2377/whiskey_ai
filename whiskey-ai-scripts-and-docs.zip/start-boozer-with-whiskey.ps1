# Boozer with WHISKEY AI Startup Script
# This script starts both the Boozer application and WHISKEY AI system

Write-Host "=== Starting Boozer Application with WHISKEY AI ===" -ForegroundColor Green

# Check if we're in the right directory
if (-not (Test-Path "backend") -or -not (Test-Path "frontend") -or -not (Test-Path "whiskey")) {
    Write-Host "Error: This script must be run from the Boozer project root directory" -ForegroundColor Red
    exit 1
}

# Function to check if a port is in use
function Test-Port {
    param([int]$Port)
    $connections = Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue
    return $connections.Count -gt 0
}

# Check if ports are already in use
if (Test-Port 8081) {
    Write-Host "Warning: Port 8081 (Boozer) is already in use" -ForegroundColor Yellow
}

if (Test-Port 8085) {
    Write-Host "Warning: Port 8085 (WHISKEY AI) is already in use" -ForegroundColor Yellow
}

# Start WHISKEY AI in the background
Write-Host "`n1. Starting WHISKEY AI System..." -ForegroundColor Yellow
Start-Process -FilePath "powershell" -ArgumentList "-Command", "cd whiskey; java -jar target/whiskey-1.0.0.jar" -WindowStyle Minimized

# Wait a moment for WHISKEY to start
Write-Host "   Waiting for WHISKEY AI to initialize..." -ForegroundColor Cyan
Start-Sleep -Seconds 5

# Check if WHISKEY started successfully
if (Test-Port 8085) {
    Write-Host "   WHISKEY AI System is running on port 8085" -ForegroundColor Green
} else {
    Write-Host "   Warning: WHISKEY AI may not have started correctly" -ForegroundColor Yellow
}

# Start Boozer application
Write-Host "`n2. Starting Boozer Application..." -ForegroundColor Yellow

# Check if we're on Windows or Unix-like system
if ($IsWindows -or $env:OS -eq "Windows_NT") {
    # Windows - use the existing batch file
    if (Test-Path "start-servers.bat") {
        Start-Process -FilePath "start-servers.bat" -WindowStyle Minimized
    } else {
        Write-Host "   Warning: start-servers.bat not found, starting manually..." -ForegroundColor Yellow
        # Try to start backend and frontend manually
        if (Test-Path "backend") {
            Start-Process -FilePath "powershell" -ArgumentList "-Command", "cd backend; ./mvnw spring-boot:run" -WindowStyle Minimized
        }
        if (Test-Path "frontend") {
            Start-Process -FilePath "powershell" -ArgumentList "-Command", "cd frontend; npm start" -WindowStyle Minimized
        }
    }
} else {
    # Unix-like system
    Start-Process -FilePath "bash" -ArgumentList "start-servers.sh" -WindowStyle Minimized
}

# Wait a moment for Boozer to start
Write-Host "   Waiting for Boozer Application to initialize..." -ForegroundColor Cyan
Start-Sleep -Seconds 5

# Check if Boozer started successfully
if (Test-Port 8081) {
    Write-Host "   Boozer Application is running on port 8081" -ForegroundColor Green
} else {
    Write-Host "   Warning: Boozer Application may not have started correctly" -ForegroundColor Yellow
}

# Display access information
Write-Host "`n=== Access Information ===" -ForegroundColor Green
Write-Host "Boozer Application: http://localhost:8081" -ForegroundColor Cyan
Write-Host "WHISKEY AI API: http://localhost:8085/api/whiskey" -ForegroundColor Cyan
Write-Host "WHISKEY Health Check: http://localhost:8085/api/whiskey/health" -ForegroundColor Cyan

# Display next steps
Write-Host "`n=== Next Steps ===" -ForegroundColor Green
Write-Host "1. Open your browser and navigate to http://localhost:8081 for the Boozer application" -ForegroundColor Cyan
Write-Host "2. Use the WHISKEY API at http://localhost:8085/api/whiskey for AI engineering tasks" -ForegroundColor Cyan
Write-Host "3. Check the WHISKEY_API_USAGE.md file for API documentation" -ForegroundColor Cyan
Write-Host "4. Run the whiskey-client.ps1 script to test WHISKEY functionality" -ForegroundColor Cyan

Write-Host "`n=== Systems Started Successfully ===" -ForegroundColor Green
Write-Host "Press any key to exit..." -ForegroundColor Yellow
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")