# WHISKEY AI System Documentation

## Overview
WHISKEY is an autonomous AI engineer system designed to handle all technical aspects of the Boozer application. It can modify code, run CI/CD operations, manage infrastructure, and perform autonomous maintenance.

## Architecture Components

### 1. AI Orchestrator (Core Brain)
- Main coordination point for all WHISKEY operations
- Task execution and management
- Concurrent processing with CompletableFuture

### 2. Repo Agent (Code RW)
- Code analysis and understanding
- Code generation and modification
- Version control operations

### 3. CI/CD & Test Runner
- Automated testing (unit, integration, e2e)
- Build automation
- Deployment orchestration

### 4. Infra Agent (Deploy & Ops)
- Infrastructure deployment and scaling
- Health monitoring
- Resource management

### 5. Monitoring Agent
- System metrics collection
- Anomaly detection
- Performance insights

### 6. Policy Engine (Governance)
- Task validation and approval
- Safety compliance checking
- Access control

### 7. Feedback Loop (Learning)
- System feedback processing
- Performance optimization
- Continuous learning

## How to Run WHISKEY

### Prerequisites
- Java 11 or higher
- Maven 3.6 or higher
- Spring Boot 2.7.x

### Running WHISKEY Service
1. Navigate to the `whiskey` directory:
   ```
   cd whiskey
   ```

2. Build the service:
   ```
   mvn clean package
   ```

3. Run the service:
   ```
   java -jar target/whiskey-1.0.0.jar
   ```

   Or use the provided batch script:
   ```
   run-whiskey.bat
   ```

### Running with the Parent Project
1. From the root directory, you can build both modules:
   ```
   mvn clean package
   ```

2. Run the backend service:
   ```
   cd backend
   java -jar target/backend-0.0.1-SNAPSHOT.jar
   ```

3. Run the WHISKEY service:
   ```
   cd whiskey
   java -jar target/whiskey-1.0.0.jar
   ```

## API Endpoints

### WHISKEY Internal API (Port 8085)
- `POST /api/whiskey/task` - Submit a new task
- `GET /api/whiskey/task/{taskId}` - Get task status
- `GET /api/whiskey/health` - Get system health status
- `GET /api/whiskey/metrics` - Get system metrics
- `GET /api/whiskey/recommendations` - Get system recommendations

### Boozer Backend Integration (Port 8080)
- `GET /api/admin/whiskey/status` - Get WHISKEY status (ADMIN only)
- `POST /api/admin/whiskey/task` - Submit task to WHISKEY (ADMIN only)
- `POST /api/admin/whiskey/code-modification` - Request code modification (ADMIN only)
- `POST /api/admin/whiskey/optimization` - Request system optimization (ADMIN only)
- `POST /api/admin/whiskey/maintenance` - Request autonomous maintenance (ADMIN only)

## Task Types
- CODE_MODIFICATION
- CI_CD_OPERATION
- INFRASTRUCTURE_OPERATION
- MONITORING_OPERATION
- FEATURE_DEVELOPMENT
- BUG_FIX
- SECURITY_PATCH
- PERFORMANCE_OPTIMIZATION
- DATABASE_MIGRATION
- AUTONOMOUS_MAINTENANCE

## Security
WHISKEY enforces strict policies through its Policy Engine to ensure safe operations. All tasks are validated before execution. Only ADMIN users can interact with WHISKEY through the Boozer backend.

## Integration with Boozer Application
WHISKEY integrates with the existing Boozer application through REST APIs. ADMIN users can access WHISKEY functionality through the admin dashboard.

## Monitoring and Maintenance
WHISKEY includes built-in monitoring and autonomous maintenance capabilities. The system continuously monitors its own health and performance, and can perform self-optimization tasks.

## Extending WHISKEY
To extend WHISKEY functionality:
1. Add new task types to the WhiskeyTask enum
2. Implement new agent classes for specific capabilities
3. Update the WhiskeyOrchestrator to handle new task types
4. Add new REST endpoints as needed