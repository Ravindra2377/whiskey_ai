# Script to delete all Boozer files
# WARNING: This will permanently delete all Boozer files
# Make sure you have backups before running this script

Write-Host "WARNING: This script will permanently delete all Boozer files!" -ForegroundColor Red
Write-Host "Make sure you have backups before proceeding." -ForegroundColor Red
Write-Host ""

$confirmation = Read-Host "Are you sure you want to delete all Boozer files? (yes/no)"

if ($confirmation -eq "yes") {
    Write-Host "Deleting Boozer files..." -ForegroundColor Yellow
    
    # Delete the main Boozer directory
    Remove-Item -Path "D:\OneDrive\Desktop\Boozer_App_Main" -Recurse -Force
    
    Write-Host "Boozer files have been deleted." -ForegroundColor Green
    Write-Host "Only the WHISKEY AI system remains in D:\OneDrive\Desktop\WHISKEY_Standalone" -ForegroundColor Cyan
} else {
    Write-Host "Operation cancelled. No files were deleted." -ForegroundColor Green
}