# WHISKEY Permanent File Migration

## Overview

This document describes how to permanently migrate all files to the WHISKEY AI database and clean the directory to keep only WHISKEY-related files. This process ensures that all your project files are stored in the database while maintaining a clean directory structure with only WHISKEY components.

## How It Works

The migration process:
1. Imports all files from the current directory to the WHISKEY database
2. Cleans the directory by removing all non-WHISKEY files
3. Keeps only essential WHISKEY files and tools
4. Maintains access to all files through WHISKEY API endpoints

## Files Kept After Migration

The following files and directories are preserved after migration:
- `whiskey/` - Main WHISKEY AI system
- `whiskey-ai-*` - WHISKEY AI related files and directories
- `WHISKEY_*` - WHISKEY documentation and configuration files
- `import-boozer-files.*` - File import scripts
- `migrate-to-whiskey-database.*` - Migration scripts
- `*.zip` - Archive files

## Prerequisites

1. WHISKEY AI system must be running
2. PostgreSQL database must be accessible
3. All files to be migrated should be in the current directory

## Usage

### Method 1: PowerShell Script (Windows)
```powershell
.\migrate-to-whiskey-database.ps1
```

### Method 2: Batch File (Windows)
```cmd
migrate-to-whiskey-database.bat
```

### Method 3: Python Script (Cross-platform)
```bash
python migrate-to-whiskey-database.py
```

## Process Steps

1. **Health Check**: Verifies WHISKEY is running and accessible
2. **File Import**: Imports all files from current directory to WHISKEY database
3. **Verification**: Confirms files were successfully imported
4. **Directory Cleanup**: Removes all non-essential files and directories
5. **Completion**: Reports migration status and provides access information

## Accessing Files After Migration

Once migrated, all files can be accessed through WHISKEY API endpoints:

### List All Files
```
GET http://localhost:8085/api/whiskey/boozer-files
```

### Search Files
```
GET http://localhost:8085/api/whiskey/boozer-files/search?query={searchTerm}
```

### Get File by Path
```
GET http://localhost:8085/api/whiskey/boozer-files/path/{filePath}
```

### Get File Content
```
GET http://localhost:8085/api/whiskey/boozer-files/content/{filePath}
```

### File Information
```
GET http://localhost:8085/api/whiskey/boozer-files/info
```

## Benefits

1. **Permanent Storage**: All files stored securely in PostgreSQL database
2. **Clean Directory**: Reduced clutter with only essential WHISKEY files
3. **Centralized Access**: All files accessible through single API
4. **Persistent Availability**: Files available even after directory cleanup
5. **Searchable**: Full-text search capabilities for all migrated files

## Security Considerations

1. **Database Security**: Ensure PostgreSQL credentials are secure
2. **API Access**: Protect WHISKEY API endpoints with authentication
3. **File Content**: Only migrate files that should be stored in the database
4. **Backup**: Consider backing up important files before migration

## Troubleshooting

### Common Issues

1. **WHISKEY Not Running**: Start WHISKEY before running migration
2. **Database Connection**: Check PostgreSQL connectivity
3. **File Access**: Ensure scripts have permission to read files
4. **API Errors**: Verify WHISKEY is functioning correctly

### Diagnostic Commands

Check WHISKEY health:
```
GET http://localhost:8085/api/whiskey/health
```

Get file import statistics:
```
GET http://localhost:8085/api/whiskey/boozer-files/info
```

List all files in database:
```
GET http://localhost:8085/api/whiskey/boozer-files
```

## Recovery

If you need to recover files after migration:
1. Access files through WHISKEY API endpoints
2. Download file content as needed
3. Recreate directory structure if necessary

## Example Usage

### Before Migration
```
project/
├── backend/
├── frontend/
├── documentation/
├── whiskey/
├── README.md
├── config.json
└── ...
```

### After Migration
```
project/
├── whiskey/
├── WHISKEY_DOCUMENTATION.md
├── import-boozer-files.py
└── migrate-to-whiskey-database.py
```

All original files are now stored in the WHISKEY database and accessible through API endpoints.