package com.whiskey.ai;

import com.whiskey.ai.dto.TaskRequestDTO;
import com.whiskey.ai.dto.TaskResponseDTO;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.List;
import java.util.ArrayList;

@RestController
@RequestMapping("/api/whiskey")
public class WhiskeyController {
    
    private final WhiskeyOrchestrator whiskeyOrchestrator;
    private final Map<String, TaskStatus> taskStatusMap = new ConcurrentHashMap<>();
    
    public WhiskeyController() {
        this.whiskeyOrchestrator = new WhiskeyOrchestrator();
    }
    
    /**
     * Endpoint to submit a task to WHISKEY
     */
    @PostMapping("/task")
    public ResponseEntity<TaskResponseDTO> submitTask(@RequestBody TaskRequestDTO taskDTO) {
        try {
            // Convert DTO to domain object
            WhiskeyTask task = new WhiskeyTask();
            task.setType(taskDTO.getType());
            task.setDescription(taskDTO.getDescription());
            task.setParameters(taskDTO.getParameters());
            task.setCreatedBy(taskDTO.getCreatedBy());
            
            // Generate task ID
            String taskId = String.valueOf(System.currentTimeMillis());
            
            // Store initial task status
            taskStatusMap.put(taskId, new TaskStatus(taskId, "SUBMITTED", task.getType().toString(), 
                "Task has been submitted for processing", 0));
            
            // Execute task asynchronously
            CompletableFuture<WhiskeyResult> futureResult = whiskeyOrchestrator.executeTask(task);
            
            // Add callback to update task status when completed
            futureResult.thenAccept(result -> {
                TaskStatus status = taskStatusMap.get(taskId);
                if (status != null) {
                    if (result.isSuccessful()) {
                        status.setStatus("COMPLETED");
                        status.setMessage("Task completed successfully");
                        status.setProgress(100);
                    } else {
                        status.setStatus("FAILED");
                        status.setMessage("Task failed: " + result.getMessage());
                    }
                    status.setCompletedAt(System.currentTimeMillis());
                }
            }).exceptionally(throwable -> {
                TaskStatus status = taskStatusMap.get(taskId);
                if (status != null) {
                    status.setStatus("FAILED");
                    status.setMessage("Task failed with exception: " + throwable.getMessage());
                    status.setCompletedAt(System.currentTimeMillis());
                }
                return null;
            });
            
            // Return immediate response with task ID
            TaskResponseDTO response = new TaskResponseDTO(
                "ACCEPTED",
                "Task submitted successfully",
                taskId,
                task.getType().toString()
            );
            
            return ResponseEntity.accepted().body(response);
        } catch (Exception e) {
            TaskResponseDTO response = new TaskResponseDTO(
                "ERROR",
                "Failed to submit task: " + e.getMessage(),
                null,
                null
            );
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
    
    /**
     * Endpoint to trigger autonomous maintenance
     */
    @PostMapping("/maintenance")
    public ResponseEntity<TaskResponseDTO> triggerMaintenance() {
        try {
            // Create a maintenance task
            WhiskeyTask task = new WhiskeyTask();
            task.setType(WhiskeyTask.TaskType.AUTONOMOUS_MAINTENANCE);
            task.setDescription("Autonomous system maintenance");
            task.setCreatedBy("SYSTEM");
            task.setParameters(new HashMap<>());
            
            // Generate task ID
            String taskId = String.valueOf(System.currentTimeMillis());
            
            // Store initial task status
            taskStatusMap.put(taskId, new TaskStatus(taskId, "SUBMITTED", task.getType().toString(), 
                "Autonomous maintenance task has been submitted for processing", 0));
            
            // Execute task asynchronously
            CompletableFuture<WhiskeyResult> futureResult = whiskeyOrchestrator.executeTask(task);
            
            // Add callback to update task status when completed
            futureResult.thenAccept(result -> {
                TaskStatus status = taskStatusMap.get(taskId);
                if (status != null) {
                    if (result.isSuccessful()) {
                        status.setStatus("COMPLETED");
                        status.setMessage("Autonomous maintenance completed successfully");
                        status.setProgress(100);
                    } else {
                        status.setStatus("FAILED");
                        status.setMessage("Autonomous maintenance failed: " + result.getMessage());
                    }
                    status.setCompletedAt(System.currentTimeMillis());
                }
            }).exceptionally(throwable -> {
                TaskStatus status = taskStatusMap.get(taskId);
                if (status != null) {
                    status.setStatus("FAILED");
                    status.setMessage("Autonomous maintenance failed with exception: " + throwable.getMessage());
                    status.setCompletedAt(System.currentTimeMillis());
                }
                return null;
            });
            
            // Return immediate response with task ID
            TaskResponseDTO response = new TaskResponseDTO(
                "ACCEPTED",
                "Autonomous maintenance task submitted successfully",
                taskId,
                task.getType().toString()
            );
            
            return ResponseEntity.accepted().body(response);
        } catch (Exception e) {
            TaskResponseDTO response = new TaskResponseDTO(
                "ERROR",
                "Failed to trigger maintenance: " + e.getMessage(),
                null,
                null
            );
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
    
    /**
     * Endpoint to get task status
     */
    @GetMapping("/task/{taskId}")
    public ResponseEntity<TaskStatus> getTaskStatus(@PathVariable String taskId) {
        TaskStatus status = taskStatusMap.get(taskId);
        if (status == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(status);
    }
    
    /**
     * Endpoint to get all tasks
     */
    @GetMapping("/tasks")
    public ResponseEntity<List<TaskStatus>> getAllTasks() {
        return ResponseEntity.ok(new ArrayList<>(taskStatusMap.values()));
    }
    
    /**
     * Endpoint to cancel a task
     */
    @DeleteMapping("/task/{taskId}")
    public ResponseEntity<Map<String, Object>> cancelTask(@PathVariable String taskId) {
        TaskStatus status = taskStatusMap.get(taskId);
        if (status == null) {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "ERROR");
            response.put("message", "Task not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
        
        // In a real implementation, we would cancel the actual task
        status.setStatus("CANCELLED");
        status.setMessage("Task was cancelled by user");
        status.setCompletedAt(System.currentTimeMillis());
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", "SUCCESS");
        response.put("message", "Task cancelled successfully");
        return ResponseEntity.ok(response);
    }
    
    /**
     * Endpoint to get system health
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> getHealth() {
        Map<String, Object> response = new HashMap<>();
        
        response.put("status", "HEALTHY");
        response.put("version", "1.0.0");
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Endpoint to get system information and capabilities
     */
    @GetMapping("/info")
    public ResponseEntity<Map<String, Object>> getSystemInfo() {
        Map<String, Object> response = new HashMap<>();
        
        response.put("name", "WHISKEY AI System");
        response.put("version", "1.0.0");
        response.put("description", "Autonomous AI Engineer for Boozer Application");
        
        Map<String, Object> capabilities = new HashMap<>();
        capabilities.put("taskTypes", WhiskeyTask.TaskType.values());
        capabilities.put("supportedOperations", new String[]{
            "Code Analysis",
            "Code Generation",
            "Code Modification",
            "Testing",
            "Deployment",
            "Monitoring",
            "Performance Optimization",
            "Bug Fixing",
            "Security Patching"
        });
        
        response.put("capabilities", capabilities);
        
        Map<String, Object> system = new HashMap<>();
        system.put("javaVersion", System.getProperty("java.version"));
        system.put("osName", System.getProperty("os.name"));
        system.put("osVersion", System.getProperty("os.version"));
        system.put("availableProcessors", Runtime.getRuntime().availableProcessors());
        system.put("maxMemory", Runtime.getRuntime().maxMemory());
        
        response.put("system", system);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Endpoint to get system metrics
     */
    @GetMapping("/metrics")
    public ResponseEntity<Map<String, Object>> getMetrics() {
        Map<String, Object> response = new HashMap<>();
        
        // In a real implementation, this would return actual metrics
        response.put("cpuUsage", 45.2);
        response.put("memoryUsage", 67.8);
        response.put("diskUsage", 34.1);
        response.put("activeTasks", taskStatusMap.values().stream()
            .filter(status -> "SUBMITTED".equals(status.getStatus()) || "PROCESSING".equals(status.getStatus()))
            .count());
        response.put("completedTasks", taskStatusMap.values().stream()
            .filter(status -> "COMPLETED".equals(status.getStatus()))
            .count());
        response.put("failedTasks", taskStatusMap.values().stream()
            .filter(status -> "FAILED".equals(status.getStatus()))
            .count());
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Endpoint to get recommendations
     */
    @GetMapping("/recommendations")
    public ResponseEntity<Map<String, Object>> getRecommendations() {
        Map<String, Object> response = new HashMap<>();
        
        // In a real implementation, this would return actual recommendations
        response.put("status", "SUCCESS");
        response.put("count", 2);
        response.put("recommendations", new String[]{
            "Optimize database queries in user service",
            "Add circuit breaker for payment service"
        });
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Task status class to track task progress
     */
    public static class TaskStatus {
        private String taskId;
        private String status;
        private String taskType;
        private String message;
        private int progress;
        private long createdAt;
        private Long completedAt;
        
        public TaskStatus() {
            this.createdAt = System.currentTimeMillis();
        }
        
        public TaskStatus(String taskId, String status, String taskType, String message, int progress) {
            this();
            this.taskId = taskId;
            this.status = status;
            this.taskType = taskType;
            this.message = message;
            this.progress = progress;
        }
        
        // Getters and setters
        public String getTaskId() { return taskId; }
        public void setTaskId(String taskId) { this.taskId = taskId; }
        
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        
        public String getTaskType() { return taskType; }
        public void setTaskType(String taskType) { this.taskType = taskType; }
        
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        
        public int getProgress() { return progress; }
        public void setProgress(int progress) { this.progress = progress; }
        
        public long getCreatedAt() { return createdAt; }
        public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
        
        public Long getCompletedAt() { return completedAt; }
        public void setCompletedAt(Long completedAt) { this.completedAt = completedAt; }
    }
}
